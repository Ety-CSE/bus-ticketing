jQuery(document).ready(function($) {
      // datatable
   $('#table').DataTable();

/**
 *Police station page
 get district by division
 **/
// $('#division').change(function(){
//     var id = $(this).val();
//     var url = '<?php echo site_url('admin/division/district_dw/') ?>'+id;

//       $.get( url, function( data ) {
//         $( "#district" ).html( data );
//       });     
//     // alert('division Changed')
//   });


});