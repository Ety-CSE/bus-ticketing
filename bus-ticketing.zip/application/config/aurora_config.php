<?php
$config['site_name'] = 'AURORA RENT A CAR';
$config['email'] = 'manishankarvakta@gmail.com';
$config['phone'] = '+880 1683 723969';
$config['author'] = 'Manishankar Vakta';
$config['web'] = 'www.vakta.me';
$config['com_web'] = 'www.auroratec.net';
$config['logo'] = 'logo-dark.png';
$config['logo-height'] = '50';
